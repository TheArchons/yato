"""Configuration for tests, changes test directory to /yato/"""

import sys
sys.path.append('yato')
